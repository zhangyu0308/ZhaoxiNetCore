﻿// This is only used for E2E tests to verify that we're correctly serving static content.
// Later this will be replaced with something more useful.
window.customJsWasLoaded = true;
