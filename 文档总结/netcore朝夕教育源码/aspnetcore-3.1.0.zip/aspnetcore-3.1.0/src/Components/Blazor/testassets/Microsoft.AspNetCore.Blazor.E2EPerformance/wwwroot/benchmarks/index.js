import { HtmlUI } from './lib/minibench/minibench.js';
import './appStartup.js';
import './renderList.js';
import './jsonHandling.js';

new HtmlUI('E2E Performance', '#display');
