# Minibench

A simple harness for benchmarking JavaScript code.

Supports both synchronous and asynchronous code being benchmarked, plus both sync/async setup and teardown logic.

## Sample

See `sample-benchmarks.js`. To run it, serve `sample.html` from a local webserver.

## Caveats

Absolutely no support provided.

## License

MIT
