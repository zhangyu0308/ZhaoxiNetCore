// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

namespace MonoSanityClient
{
    // Note: Not used at runtime. This exists only to give the server app some type to reference.
    // In realistic scenarios you'd have a Program class for real.

    public class Program
    {
        static void Main()
        {
        }
    }
}
