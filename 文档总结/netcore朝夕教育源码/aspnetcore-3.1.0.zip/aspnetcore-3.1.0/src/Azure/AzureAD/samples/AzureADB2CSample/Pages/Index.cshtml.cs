﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace AzureADB2CSample.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
