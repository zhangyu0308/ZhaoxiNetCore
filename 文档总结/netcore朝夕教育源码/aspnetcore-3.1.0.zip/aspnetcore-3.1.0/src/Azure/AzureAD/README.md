Azure Active Directory Integration
==================================

ASP.NET Core Azure Active Directory Integration provides seamless authentication integration with different Azure Active Directory services like Azure Active Directory and Azure Active Directory B2C for ASP.NET Core applications.