# Helix content

The content of this folder is included in the test payload for each Helix work item. The code here is mean to be used alongside test binaries.
